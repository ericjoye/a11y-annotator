# Screenshots — a11y-annotator

**Product:** a11y-annotator — Privacy-first Chrome extension that scans any page for accessibility issues, lets you pin and annotate them visually, and exports shareable reports.

**Type:** Chrome Extension (Manifest V3)

---

## Screenshot 1: Main Interface — Side Panel Issue Dashboard

**What to capture:** The Chrome side panel showing the accessibility issue dashboard after scanning a webpage. Show the issue list grouped by type with severity badges (red/yellow/blue pins) and WCAG references.

**ASCII Mockup:**

```
┌─────────────────────────────────────────────┐
│  🔍 a11y-annotator          [Scan] [Export] │
├─────────────────────────────────────────────┤
│  📊 Scan Results — 12 issues found          │
│  ─────────────────────────────────────────  │
│                                             │
│  🔴 ERRORS (5)                              │
│  ┌───────────────────────────────────────┐  │
│  │ 🔴 Missing alt text          WCAG 1.1.1│ │
│  │    <img class="hero" />               │  │
│  │    📝 "Hero image needs description"  │  │
│  ├───────────────────────────────────────┤  │
│  │ 🔴 Low contrast (2.1:1)      WCAG 1.4.3│ │
│  │    <p class="subtitle">               │  │
│  │    📝 ""                              │  │
│  ├───────────────────────────────────────┤  │
│  │ 🔴 Missing form label        WCAG 1.3.1│ │
│  │    <input type="email">               │  │
│  │    📝 "No associated <label>"         │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  🟡 WARNINGS (4)                            │
│  ┌───────────────────────────────────────┐  │
│  │ 🟡 Empty link text           WCAG 2.4.4│ │
│  │    <a href="/"><i class="icon"></a>   │  │
│  ├───────────────────────────────────────┤  │
│  │ 🟡 Heading skip (h1→h3)     WCAG 1.3.1│ │
│  │    <h3>Subsection</h3>                │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  🔵 INFO (3)                                │
│  ┌───────────────────────────────────────┐  │
│  │ 🔵 Small touch target        WCAG 2.5.5│ │
│  │    <button style="16px">              │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  [📸 Screenshot]  [📋 Copy Report]          │
└─────────────────────────────────────────────┘
```

---

## Screenshot 2: Key Feature — Visual Pins on Page

**What to capture:** A webpage with color-coded pins/overlays positioned on problematic elements. Show red pins on images without alt text, yellow pins on contrast issues, and the annotation popup when a pin is clicked.

**ASCII Mockup:**

```
┌──────────────────────────────────────────────────────────┐
│  🌐 example.com/blog                                     │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  ┌────────────────────────────────────────────────┐      │
│  │                                                 │      │
│  │   [🔴]  ← Pin on hero image                    │      │
│  │         (missing alt text)                      │      │
│  │                                                 │      │
│  │   Welcome to Our Blog                           │      │
│  │                                                 │      │
│  └────────────────────────────────────────────────┘      │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐               │
│  │ [🔴]     │  │          │  │ [🟡]     │               │
│  │ No alt   │  │ Card 2   │  │ Low      │               │
│  │          │  │          │  │ contrast │               │
│  └──────────┘  └──────────┘  └──────────┘               │
│                                                          │
│  ┌──────────────────────────────────────────────┐        │
│  │  📝 Annotation:                               │        │
│  │  ┌────────────────────────────────────────┐  │        │
│  │  │ Hero image needs descriptive alt text  │  │        │
│  │  │ for screen reader users               │  │        │
│  │  └────────────────────────────────────────┘  │        │
│  │                              [Save] [Cancel] │        │
│  └──────────────────────────────────────────────┘        │
│                                                          │
│  Toggle: [Overlay ON ●○○]  Shortcut: Alt+A              │
└──────────────────────────────────────────────────────────┘
```

---

## Screenshot 3: Export Report Options

**What to capture:** The export dialog showing the Markdown report preview with page URL, timestamp, issue list, severity, WCAG references, and annotation notes.

**ASCII Mockup:**

```
┌─────────────────────────────────────────────┐
│  📋 Export Accessibility Report             │
├─────────────────────────────────────────────┤
│                                             │
│  Format:  ○ Markdown  ○ CSV  ● JSON (Pro)  │
│                                             │
│  ┌───────────────────────────────────────┐  │
│  │ # Accessibility Report                │  │
│  │                                       │  │
│  │ **URL:** https://example.com/blog     │  │
│  │ **Scanned:** 2026-06-20 14:32 UTC     │  │
│  │ **Issues:** 12 (5 errors, 4 warnings, │  │
│  │             3 info)                   │  │
│  │                                       │  │
│  │ ## Errors                             │  │
│  │                                       │  │
│  │ ### 1. Missing alt text               │  │
│  │ - **Severity:** Error                 │  │
│  │ - **WCAG:** 1.1.1 Non-text Content   │  │
│  │ - **Element:** `img.hero`             │  │
│  │ - **Note:** "Hero image needs..."     │  │
│  │                                       │  │
│  │ ### 2. Low contrast ratio             │  │
│  │ - **Severity:** Error                 │  │
│  │ - **WCAG:** 1.4.3 Minimum Contrast   │  │
│  │ - **Element:** `p.subtitle`           │  │
│  │ - **Note:** ""                        │  │
│  │                                       │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  [📋 Copy to Clipboard]  [💾 Download .md]  │
└─────────────────────────────────────────────┘
```

---

## Screenshot 4: Screenshot Capture with Annotations

**What to capture:** The viewport screenshot with annotation pins overlaid, showing how the exported PNG looks with numbered pins and a legend.

**ASCII Mockup:**

```
┌──────────────────────────────────────────────────────────┐
│  📸 Screenshot with Annotations                         │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  ┌────────────────────────────────────────────────┐      │
│  │  ①  ②                                          │      │
│  │  ┌──────────────────────────────────────┐      │      │
│  │  │                                       │      │      │
│  │  │   Welcome to Our Blog                 │      │      │
│  │  │                                       │      │      │
│  │  └──────────────────────────────────────┘      │      │
│  │                                                 │      │
│  │  ③       ④       ⑤                             │      │
│  │  ┌────┐  ┌────┐  ┌────┐                        │      │
│  │  │    │  │    │  │    │                        │      │
│  │  └────┘  └────┘  └────┘                        │      │
│  │                                                 │      │
│  │  ⑥  ⑦                                          │      │
│  │  ┌──────────────────────────────────────┐      │      │
│  │  │  Footer content here                  │      │      │
│  │  └──────────────────────────────────────┘      │      │
│  └────────────────────────────────────────────────┘      │
│                                                          │
│  Legend:                                                 │
│  ①🔴 Missing alt text  ②🔴 Missing alt text             │
│  ③🔴 No label          ④🟡 Low contrast                 │
│  ⑤🟡 Empty link        ⑥🔴 Missing lang                 │
│  ⑦🟡 Heading skip                                       │
│                                                          │
│  [💾 Download PNG]  [📋 Copy to Clipboard]               │
└──────────────────────────────────────────────────────────┘
```

---

## Notes for Actual Screenshots

1. **Use a real website** with known accessibility issues (e.g., a WordPress blog or news site)
2. **Show the side panel** docked to the right side of Chrome — this is the primary UI
3. **Color coding is critical:** Red pins for errors, yellow for warnings, blue for info
4. **Annotation popup** should look like a clean card with a textarea and Save/Cancel buttons
5. **Export report** should show realistic Markdown formatting in a modal or preview pane
6. **Screenshot capture** should show numbered pins overlaid on a real webpage screenshot
7. **Dark/light mode:** Capture in light mode for consistency
8. **Extension icon** should be visible in the toolbar (puzzle piece menu)
